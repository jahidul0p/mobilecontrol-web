MOBILECONTROL PRO - FRONT PAGE UPDATE

This bundle contains:
- index.html
- assets/mobilecontrol-hero.png
- assets/family-safety-visual.png

IMPORTANT:
1. Extract this ZIP on your computer.
2. In your GitHub repository, replace the existing root index.html with this index.html.
3. Upload the complete assets folder next to index.html (do not move the images into another folder).
4. Commit the changes. Render should deploy from the updated repository.

The HTML references the images using relative paths under assets/.
The existing login/signup API calls, modal logic, and dashboard redirect were kept from the supplied HTML.
